# ESP32-Arduino-Servo-Library
Generate RC servo signal on a selected pin.

Base on [servo library for stm32f4 (d2a4a47)](https://github.com/arduino-libraries/Servo/blob/master/src/stm32f4/ServoTimers.h).

The same interface as Arduino/Servo: https://www.arduino.cc/en/Reference/Servo

Also available through the PlatformIO: http://platformio.org/lib/show/1739/ServoESP32